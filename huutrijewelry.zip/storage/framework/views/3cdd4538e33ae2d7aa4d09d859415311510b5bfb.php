
<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{ url('/') }}"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('user.blog.list')); ?>">Blog</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                <?php echo e($post->slug); ?> <!-- Hiển thị slug của bài viết -->
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="blog-main-wrapper section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 order-2">
                <aside class="blog-sidebar-wrapper">
                    <div class="blog-sidebar">
                        <h5 class="title">Danh mục bài viết</h5>
                        <ul class="blog-archive blog-category">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="#"><?php echo e($category->name); ?> (<?php echo e($category->posts_count); ?>)</a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="blog-sidebar">
                        <h5 class="title">Bài viết mỗi tháng</h5>
                        <ul class="blog-archive">
                            <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php
                                // Kiểm tra nếu tháng hợp lệ
                                $monthName = '';
                                if ($archive->month >= 1 && $archive->month <= 12) {
                                    // Chuyển tháng từ số thành tên tháng (Tháng 1, Tháng 2, ...)
                                    $monthName='Tháng ' . DateTime::createFromFormat('!m', $archive->month)->format('m');
                                    }
                                    ?>
                                    <a href="#">
                                        <?php echo e($monthName); ?> (<?php echo e($archive->post_count); ?>)
                                    </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </aside>
            </div>
            <div class="col-lg-9 order-1">
                <div class="blog-item-wrapper">
                    <!-- blog post item start -->
                    <div class="blog-post-item blog-details-post">
                        <figure class="blog-thumb">
                            <div class="blog-carousel-2 slick-row-15 slick-arrow-style slick-dot-style">
                                <?php if(is_array($post->images) || is_object($post->images)): ?>
                                <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="blog-single-slide">
                                    <img src="<?php echo e(asset('public/admin/images/post/' . $image)); ?>" alt="blog image">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="blog-single-slide">
                                    <img src="<?php echo e(asset('public/admin/images/post/' . $post->images)); ?>" alt="blog image">
                                </div>
                                <?php endif; ?>
                            </div>
                        </figure>

                        <div class="blog-content">
                            <h3 class="blog-title">
                                <?php echo e($post->title); ?>

                            </h3>
                            <div class="blog-meta">
                                <p><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d/m/Y')); ?> | <a href="#"><?php echo e($post->categoryPost->name); ?></a></p>
                            </div>
                            <div class="entry-summary">
                                <p><?php echo $post->content; ?></p>

                                <div class="blog-share-link">
                                    <h6>Share :</h6>
                                    <div class="blog-social-icon">
                                        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/user/blog/blog-details.blade.php ENDPATH**/ ?>