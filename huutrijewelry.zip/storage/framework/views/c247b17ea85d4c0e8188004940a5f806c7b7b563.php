

<?php $__env->startSection('content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Danh sách Size cho từng sản phẩm
        </div>
        <div class="row w3-res-tb">
            <div class="col-sm-5 m-b-xs">
                <a href="<?php echo e(route('admin.size.create')); ?>" class="btn btn-success">Thêm mới Size</a>
            </div>
            <div class="col-sm-3">
                <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Sản phẩm</th>
                        <th>Size</th>
                        <th>Trạng thái</th>
                        <th>Ngày tạo</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($size->size_id); ?></td>
                        <td><?php echo e($size->goldProduct->product_name ?? 'Không xác định'); ?></td>
                        <td>
                            <?php echo e($size->size ?? 'Sản phẩm này không có size'); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.size.update-status', $size->size_id)); ?>" class="btn btn-sm <?php echo e($size->status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                                <?php echo e($size->status == 1 ? 'Hiển thị' : 'Không hiển thị'); ?>

                            </a>
                        </td>
                        <td><?php echo e($size->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.size.edit', $size->size_id)); ?>" class="btn btn-info btn-sm">Sửa</a>
                            <form action="<?php echo e(route('admin.size.destroy', $size->size_id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <footer class="panel-footer-2">
            <div class="row-2">
                <div class="col-sm-7 text-right text-center-xs">
                    <ul class="pagination pagination-sm m-t-none m-b-none">
                        <!-- Nút Previous -->
                        <li class="page-item <?php echo e($sizes->onFirstPage() ? 'disabled' : ''); ?>">
                            <a class="page-link" href="<?php echo e($sizes->previousPageUrl()); ?>" aria-label="Previous">
                                <i class="fa fa-chevron-left"></i>
                            </a>
                        </li>

                        <!-- Hiển thị các số trang -->
                        <?php $__currentLoopData = $sizes->getUrlRange(1, $sizes->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($sizes->currentPage() == $page ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Nút Next -->
                        <li class="page-item <?php echo e($sizes->hasMorePages() ? '' : 'disabled'); ?>">
                            <a class="page-link" href="<?php echo e($sizes->nextPageUrl()); ?>" aria-label="Next">
                                <i class="fa fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/size/danh-sach-size.blade.php ENDPATH**/ ?>