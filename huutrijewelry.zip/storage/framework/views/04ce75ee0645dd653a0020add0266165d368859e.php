
<?php $__env->startSection('content'); ?>

<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Danh mục bài viết
        </div>
        <div class="row w3-res-tb">
            <div class="col-sm-5 m-b-xs">
                <a href="<?php echo e(route('admin.posts.create')); ?>" data-toggle="modal" class="btn btn-success">
                    Thêm mới bài viết
                </a>
            </div>
            <div class="col-sm-3">
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th style="width:20px;">
                            <label class="i-checks m-b-none">
                                <input type="checkbox"><i></i>
                            </label>
                        </th>
                        <th>ID</th>
                        <th>Tiêu đề</th>
                        <th>Slug</th>
                        <th>Mô tả</th>
                        <th>Images</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Updated</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <label class="i-checks m-b-none">
                                <input type="checkbox" name="post[]"><i></i>
                            </label>
                        </td>
                        <td><?php echo e($post->posts_id); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->slug); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit(strip_tags($post->content), 10, '...')); ?></td>

                        <td>
                            <!-- Hiển thị ảnh nếu có -->
                            <?php if($post->images): ?>
                            <img src="<?php echo e(asset('public/admin/images/post/' . $post->images)); ?>" alt="Image" style="max-width: 100px; max-height: 100px;">
                            <?php else: ?>
                            Không có ảnh
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.posts.update-status', $post->posts_id)); ?>" class="btn btn-sm <?php echo e($post->status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                                <?php echo e($post->status == 1 ? 'Mở' : 'Đóng'); ?>

                            </a>
                        </td>
                        <td><?php echo e($post->created_at); ?></td>
                        <td><?php echo e($post->updated_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.posts.edit', $post->posts_id)); ?>" class="btn btn-sm btn-info">Edit</a>
                            <br>
                            <!-- Nút Detail, mở modal -->
                            <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#postDetailModal" data-id="<?php echo e($post->posts_id); ?>" data-title="<?php echo e($post->title); ?>" data-content="<?php echo e(strip_tags($post->content)); ?>"
                                data-image="<?php echo e(asset('public/admin/images/post/' . $post->images)); ?>" data-slug="<?php echo e($post->slug); ?>">
                                Detail
                            </button>
                            <form action="<?php echo e(route('admin.posts.destroy', $post->posts_id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Hiển thị chi tiết bài viết -->
<div class="modal fade" id="postDetailModal" tabindex="-1" role="dialog" aria-labelledby="postDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="postDetailModalLabel">Chi tiết bài viết</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="postTitle">Tiêu đề</label>
                    <input type="text" class="form-control" id="postTitle" disabled>
                </div>
                <div class="form-group">
                    <label for="postSlug">Slug</label>
                    <input type="text" class="form-control" id="postSlug" disabled>
                </div>
                <div class="form-group">
                    <label for="postContent">Nội dung</label>
                    <textarea class="form-control" id="postContent" rows="5" disabled></textarea>
                </div>
                <div class="form-group">
                    <img id="postImage" style="max-width: 30%; height: auto;" alt="Image">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
            </div>
        </div>
    </div>
</div>
<script>
    // Khi nhấn vào nút Detail, hiển thị thông tin bài viết trong modal
    $('#postDetailModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget); // Lấy nút đã nhấn
        var title = button.data('title');
        var slug = button.data('slug'); // Lấy slug
        var content = button.data('content');
        var image = button.data('image');

        var modal = $(this);
        modal.find('#postTitle').val(title);
        modal.find('#postSlug').val(slug); // Điền giá trị slug vào input
        modal.find('#postContent').val(content);
        modal.find('#postImage').attr('src', image);
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/posts/danh-sach-bai-viet.blade.php ENDPATH**/ ?>