

<?php $__env->startSection('content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Danh sách tài khoản
        </div>
        <div class="row w3-res-tb">
            <div class="col-sm-5 m-b-xs">
                <a href="<?php echo e(route('admin.accounts.create')); ?>" class="btn btn-success">Thêm mới tài khoản</a>
            </div>
            <div class="col-sm-3">
                <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
            </div>

        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên</th>
                        <th>Email</th>
                        <th>Role</th> <!-- Thêm cột Role -->
                        <th>Trạng thái</th>
                        <th>Images</th>
                        <th>Ngày tạo</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($admin->admin_id); ?></td>
                        <td><?php echo e($admin->username); ?></td>
                        <td><?php echo e($admin->email); ?></td>
                        <td>
                            <?php if($admin->role): ?>
                            <?php switch($admin->role->type):
                            case (1): ?>
                            Giám đốc
                            <?php break; ?>
                            <?php case (2): ?>
                            Quản lý
                            <?php break; ?>
                            <?php case (3): ?>
                            Nhân viên
                            <?php break; ?>
                            <?php case (4): ?>
                            <?php default: ?>
                            Người chưa được kiểm duyệt
                            <?php endswitch; ?>
                            <?php else: ?>
                            Chưa xác định
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if($admin->role_id == 1): ?>
                            <span class="badge badge-warning">Quyền cao nhất không được chỉnh sửa</span>
                            <?php else: ?>
                            <a href="<?php echo e(route('admin.accounts.update-status', $admin->admin_id)); ?>" class="btn btn-sm <?php echo e($admin->status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                                <?php echo e($admin->status == 1 ? 'Hoạt động' : 'Không hoạt động'); ?>

                            </a>
                            <?php endif; ?>
                        </td>


                        <td>
                            <!-- Hiển thị ảnh nếu có -->
                            <?php if($admin->admin_image): ?>
                            <img src="<?php echo e(asset('public/admin/images/admin/' . $admin->admin_image)); ?>" alt="Image" style="max-width: 100px; max-height: 100px;">
                            <?php else: ?>
                            Không có ảnh
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($admin->created_at); ?></td>
                        <td>
                            <?php if($admin->role_id != 1): ?>
                            <a href="<?php echo e(route('admin.accounts.edit', $admin->admin_id)); ?>" class="btn btn-info btn-sm">Sửa</a>
                            <form action="<?php echo e(route('admin.accounts.destroy', $admin->admin_id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</button>
                            </form>
                            <?php else: ?>
                            <span class="badge badge-secondary">Quyền cao nhất, không thể sửa hoặc xóa</span>
                            <?php endif; ?>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <footer class="panel-footer-2">
            <div class="row-2">
                <div class="col-sm-7 text-right text-center-xs">
                    <ul class="pagination pagination-sm m-t-none m-b-none">
                        <!-- Nút Previous -->
                        <li class="page-item <?php echo e($admins->onFirstPage() ? 'disabled' : ''); ?>">
                            <a class="page-link" href="<?php echo e($admins->previousPageUrl()); ?>" aria-label="Previous">
                                <i class="fa fa-chevron-left"></i>
                            </a>
                        </li>

                        <!-- Hiển thị các số trang -->
                        <?php $__currentLoopData = $admins->getUrlRange(1, $admins->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($admins->currentPage() == $page ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Nút Next -->
                        <li class="page-item <?php echo e($admins->hasMorePages() ? '' : 'disabled'); ?>">
                            <a class="page-link" href="<?php echo e($admins->nextPageUrl()); ?>" aria-label="Next">
                                <i class="fa fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/accounts/danh-sach-tai-khoan.blade.php ENDPATH**/ ?>