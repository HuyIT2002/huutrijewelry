

<?php $__env->startSection('content'); ?>
<section class="panel">
    <header class="panel-heading">
        Chỉnh sửa tài khoản
    </header>
    <div class="panel-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <form class="form-horizontal bucket-form" method="POST" action="<?php echo e(route('admin.accounts.update', $accounts->admin_id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?> <!-- Để gửi phương thức PUT cho cập nhật -->

            <!-- Tên tài khoản -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Tên tài khoản</label>
                <div class="col-sm-6">
                    <input type="text" name="username" class="form-control" value="<?php echo e(old('username', $accounts->username)); ?>" required>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Email -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Email</label>
                <div class="col-sm-6">
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $accounts->email)); ?>" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Mật khẩu -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Mật khẩu</label>
                <div class="col-sm-6">
                    <input type="password" name="password" class="form-control">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Vai trò -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Vai trò</label>
                <div class="col-sm-6">
                    <select name="role_id" class="form-control" required>
                        <option value="">Chọn vai trò</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->role_id); ?>" <?php echo e(old('role_id', $accounts->role_id) == $role->role_id ? 'selected' : ''); ?>>
                            <?php switch($role->type):
                            case (1): ?>
                            Giám đốc
                            <?php break; ?>
                            <?php case (2): ?>
                            Quản lý
                            <?php break; ?>
                            <?php case (3): ?>
                            Nhân viên
                            <?php break; ?>
                            <?php case (4): ?>
                            Người chưa được kiểm duyệt
                            <?php break; ?>
                            <?php default: ?>
                            Không xác định
                            <?php endswitch; ?>
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Trạng thái -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Trạng thái</label>
                <div class="col-sm-6">
                    <select name="status" class="form-control" required>
                        <option value="1" <?php echo e(old('status', $accounts->status) == 1 ? 'selected' : ''); ?>>Hoạt động</option>
                        <option value="0" <?php echo e(old('status', $accounts->status) == 0 ? 'selected' : ''); ?>>Không hoạt động</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Ảnh -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Ảnh</label>
                <div class="col-sm-6">
                    <?php if($accounts->admin_image): ?>
                    <img src="<?php echo e(asset('public/admin/images/admin/' . $accounts->admin_image)); ?>" alt="Ảnh hiện tại" style="max-width: 200px; display: block; margin-bottom: 10px;">
                    <?php endif; ?>
                    <input type="file" name="admin_image" class="form-control" accept="image/*" onchange="previewImage(event)">
                    <?php $__errorArgs = ['admin_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <img id="imagePreview" src="#" alt="Ảnh bài viết" style="max-width: 200px; display: none;" />
                </div>
            </div>

            <div class="form-group">
                <div class="col-lg-offset-3 col-lg-6">
                    <button class="btn btn-primary" type="submit">Cập nhật</button>
                    <a href="<?php echo e(route('admin.accounts.index')); ?>" class="btn btn-default">Quay lại</a>
                </div>
            </div>
        </form>
    </div>
</section>

<script>
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('imagePreview');
            output.src = reader.result;
            output.style.display = 'block';
        }
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/accounts/edit.blade.php ENDPATH**/ ?>