
<?php $__env->startSection('content'); ?>
<style>
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        font-size: 16px;
        padding: 10px 20px;
        font-weight: bold;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .btn-lg {
        padding: 12px 24px;
    }
</style>
<section class="panel">
    <header class="panel-heading">
        Thêm mới sản phẩm
    </header>
    <div class="panel-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>


        <form class="form-horizontal bucket-form" method="POST" action="<?php echo e(route('admin.products.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <!-- Product Name -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Tên sản phẩm</label>
                <div class="col-sm-6">
                    <input type="text" name="product_name" id="product_name" class="form-control" value="<?php echo e(old('product_name')); ?>" required>
                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- Product Name -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Slug</label>
                <div class="col-sm-6">
                    <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e(old('slug')); ?>" required>
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-3 control-label">Số Lượng</label>
                <div class="col-sm-6">
                    <input type="text" name="so_luong" id="so_luong" class="form-control" value="<?php echo e(old('so_luong')); ?>" required>
                    <?php $__errorArgs = ['so_luong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- Product Code ID -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Mã sản phẩm</label>
                <div class="col-sm-6">
                    <input type="text" id="code_id" name="code_id" class="form-control" value="<?php echo e(old('code_id')); ?>" required>
                    <?php $__errorArgs = ['code_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Stylish button -->
                    <button type="button" class="btn btn-primary btn-lg" onclick="generateRandomCode()">Tạo Mã Ngẫu Nhiên</button>
                </div>
            </div>
            <!-- Price -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Giá</label>
                <div class="col-sm-6">
                    <input type="number" name="price" class="form-control" value="<?php echo e(old('price')); ?>" required>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- Weight (Trọng lượng) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Trọng lượng</label>
                <div class="col-sm-6">
                    <input type="text" name="trong_luong" class="form-control" value="<?php echo e(old('trong_luong')); ?>" required>
                    <?php $__errorArgs = ['trong_luong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- Material (Hàm chất liệu) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Hàm chất liệu</label>
                <div class="col-sm-6">
                    <input type="text" name="ham_chat_lieu" class="form-control" value="<?php echo e(old('ham_chat_lieu')); ?>" required>
                    <?php $__errorArgs = ['ham_chat_lieu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <!-- Main Stone Type (Loại đá chính) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Loại đá chính</label>
                <div class="col-sm-6">
                    <input type="text" name="loai_da_chinh" class="form-control" value="<?php echo e(old('loai_da_chinh')); ?>" required>
                    <?php $__errorArgs = ['loai_da_chinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Stone Size (Kích thước đá) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Kích thước đá</label>
                <div class="col-sm-6">
                    <input type="text" name="kich_thuoc_da" class="form-control" value="<?php echo e(old('kich_thuoc_da')); ?>" required>
                    <?php $__errorArgs = ['kich_thuoc_da'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Main Stone Color (Màu đá chính) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Màu đá chính</label>
                <div class="col-sm-6">
                    <input type="text" name="mau_da_chinh" class="form-control" value="<?php echo e(old('mau_da_chinh')); ?>" required>
                    <?php $__errorArgs = ['mau_da_chinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Stone Shape (Hình dạng đá) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Hình dạng đá</label>
                <div class="col-sm-6">
                    <input type="text" name="hinh_dang_da" class="form-control" value="<?php echo e(old('hinh_dang_da')); ?>" required>
                    <?php $__errorArgs = ['hinh_dang_da'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Main Stone Quantity (Số lượng đá chính) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Số lượng đá chính</label>
                <div class="col-sm-6">
                    <input type="number" name="sl_da_chinh" class="form-control" value="<?php echo e(old('sl_da_chinh')); ?>" required>
                    <?php $__errorArgs = ['sl_da_chinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Additional Stone Quantity (Số lượng đá phụ) -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Số lượng đá phụ</label>
                <div class="col-sm-6">
                    <input type="number" name="sl_da_phu" class="form-control" value="<?php echo e(old('sl_da_phu')); ?>" required>
                    <?php $__errorArgs = ['sl_da_phu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-3 control-label">Trạng thái</label>
                <div class="col-lg-6">
                    <select name="status" class="form-control m-bot15" required>
                        <option value="1" <?php echo e(old('status') == 1 ? 'selected' : ''); ?>>Hiển thị</option>
                        <option value="0" <?php echo e(old('status') == 0 ? 'selected' : ''); ?>>Không hiển thị</option>
                    </select>
                </div>
            </div>

            <!-- Trường Chọn danh mục cha -->
            <div class="form-group row d-flex align-items-center">
                <label class="col-sm-3 control-label">Danh mục con</label>
                <div class="col-sm-6">
                    <select name="category_id" class="form-control" required>
                        <option value="">Chọn danh mục sản phẩm</option>
                        <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($parentCategory->parent_categorie_id); ?>">
                            <?php echo e($parentCategory->name); ?>

                        </option>
                        <?php $__currentLoopData = $parentCategory->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->category_id); ?>" style="padding-left: 20px;">
                            -- <?php echo e($category->category_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Trường Mô tả -->
            <div class="form-group">
                <label class="col-sm-3 control-label">Mô tả</label>
                <div class="col-sm-6">
                    <textarea name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-3 control-label">Ảnh bài viết</label>
                <div class="col-sm-6">
                    <input type="file" name="images" class="form-control" accept="image/*" onchange="previewImage(event)">
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <img id="imagePreview" src="#" alt="Ảnh bài viết" style="max-width: 200px; display: none;" />
                </div>
            </div>
            <div class="form-group">
                <div class="col-lg-offset-3 col-lg-6">
                    <button class="btn btn-primary" type="submit">Tạo mới</button>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-default">Quay lại</a>
                </div>
            </div>
        </form>
        <script>
            function previewImage(event) {
                var reader = new FileReader();
                reader.onload = function() {
                    var output = document.getElementById('imagePreview');
                    output.src = reader.result;
                    output.style.display = 'block';
                }
                reader.readAsDataURL(event.target.files[0]);
            }
        </script>
        <script>
            function generateRandomCode() {
                var length = 8; // You can change the length as per your requirements
                var charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                var randomCode = '';

                for (var i = 0; i < length; i++) {
                    var randomIndex = Math.floor(Math.random() * charset.length);
                    randomCode += charset[randomIndex];
                }

                // Set the generated code into the 'code_id' input field
                document.getElementById('code_id').value = randomCode;
            }
        </script>
        <script>
            document.getElementById('product_name').addEventListener('input', function() {
                var name = this.value;

                // Hàm chuyển đổi các ký tự có dấu thành không dấu
                var slug = convertToSlug(name);

                // Gán giá trị vào ô input slug
                document.getElementById('slug').value = slug;
            });

            // Hàm chuyển đổi tên thành slug
            // Hàm chuyển đổi tên thành slug
            function convertToSlug(text) {
                return text
                    .toLowerCase() // Chuyển thành chữ thường
                    .replace(/đ/g, 'd') // Thay thế ký tự "đ" thành "d"
                    .replace(/Đ/g, 'd') // Thay thế ký tự "Đ" thành "d"
                    .normalize("NFD") // Phân tách ký tự có dấu thành 2 phần (chữ + dấu)
                    .replace(/[\u0300-\u036f]/g, "") // Loại bỏ các dấu (dấu tiếng Việt)
                    .replace(/[^a-z0-9\s-]/g, '') // Loại bỏ các ký tự không phải chữ cái, số, khoảng trắng hoặc dấu gạch ngang
                    .replace(/\s+/g, '-') // Thay khoảng trắng bằng dấu gạch ngang
                    .replace(/-+/g, '-'); // Xóa các dấu gạch ngang dư thừa
            }
        </script>


    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/products/create.blade.php ENDPATH**/ ?>