
<?php $__env->startSection('content'); ?>

<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Danh mục bài viết
        </div>
        <div class="row w3-res-tb">
            <div class="col-sm-5 m-b-xs">
                <a href="<?php echo e(route('admin.category-posts.create')); ?>" data-toggle="modal" class="btn btn-success">
                    Thêm mới danh mục bài viết
                </a>
            </div>
            <div class="col-sm-3">
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th style="width:20px;">
                            <label class="i-checks m-b-none">
                                <input type="checkbox"><i></i>
                            </label>
                        </th>
                        <th>ID</th>
                        <th>Tên danh mục</th>
                        <th>Slug</th>
                        <th>Mô tả</th>
                        <th>Trạng thái</th>
                        <th>Thời gian tạo</th>
                        <th>Thời gian sửa</th>
                        <th>Lựa chọn</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <label class="i-checks m-b-none">
                                <input type="checkbox" name="post[]"><i></i>
                            </label>
                        </td>
                        <td><?php echo e($category->category_posts_id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->slug); ?></td>
                        <td><?php echo e($category->description); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.category-posts.update-status', $category->category_posts_id)); ?>" class="btn btn-sm <?php echo e($category->status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                                <?php echo e($category->status == 1 ? 'Hiển thị' : 'Không hiển thị'); ?>

                            </a>
                        </td>
                        <td><?php echo e($category->created_at); ?></td>
                        <td><?php echo e($category->updated_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.category-posts.edit', $category->category_posts_id)); ?>" class="btn btn-sm btn-info">Sửa</a>
                            <form action="<?php echo e(route('admin.category-posts.destroy', $category->category_posts_id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/category-posts/danh-muc-bai-viet.blade.php ENDPATH**/ ?>