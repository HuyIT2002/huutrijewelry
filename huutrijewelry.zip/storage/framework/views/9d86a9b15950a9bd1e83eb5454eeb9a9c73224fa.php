
<?php $__env->startSection('content'); ?>

<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Biến động giá vàng
        </div>
        <div class="row w3-res-tb">

            <div class="col-sm-5 m-b-xs">
                <a href="<?php echo e(route('admin.parent-categories.create')); ?>" data-toggle="modal" class="btn btn-success">
                    Thêm mới giá vàng
                </a>
            </div>
            <div class="col-sm-3">
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th style="width:20px;">
                            <label class="i-checks m-b-none">
                                <input type="checkbox"><i></i>
                            </label>
                        </th>
                        <th>ID</th>
                        <th>Mua vào</th>
                        <th>Bán ra</th>
                        <th>Loại vàng</th>
                        <th>Đơn vị</th>
                        <th>Trạng thái</th>
                        <th>Thời gian tạo</th>
                        <th>Thời gian sủa</th>
                        <th>Lựa chọn</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.home_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/categories/danh-muc-cha.blade.php ENDPATH**/ ?>