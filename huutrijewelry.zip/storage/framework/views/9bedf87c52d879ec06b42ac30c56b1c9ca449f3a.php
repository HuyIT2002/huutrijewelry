			<!-- footer -->


			<div class="footer">
				<div class="wthree-copyright">
					<p><a href="https://huutrijewelry.com/">Hữu Trí Jewelry</a></p>
				</div>
			</div>

			<!-- / footer --><?php /**PATH C:\xampp\htdocs\huutrijewelry\resources\views/admin/footer/footer.blade.php ENDPATH**/ ?>